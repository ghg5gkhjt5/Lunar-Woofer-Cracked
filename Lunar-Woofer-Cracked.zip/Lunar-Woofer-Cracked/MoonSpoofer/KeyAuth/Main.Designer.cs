﻿namespace KeyAuth
{
	// Token: 0x02000007 RID: 7
	public partial class Main : global::System.Windows.Forms.Form
	{
		// Token: 0x06000073 RID: 115 RVA: 0x00006554 File Offset: 0x00004754
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			bool flag2 = flag;
			if (flag2)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000074 RID: 116 RVA: 0x00006590 File Offset: 0x00004790
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::KeyAuth.Main));
			this.label1 = new global::System.Windows.Forms.Label();
			this.guna2BorderlessForm1 = new global::Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
			this.homeBTN = new global::Guna.UI2.WinForms.Guna2Button();
			this.settingsBTN = new global::Guna.UI2.WinForms.Guna2Button();
			this.siticoneControlBox1 = new global::Siticone.UI.WinForms.SiticoneControlBox();
			this.siticoneControlBox2 = new global::Siticone.UI.WinForms.SiticoneControlBox();
			this.guna2Button4 = new global::Guna.UI2.WinForms.Guna2Button();
			this.guna2Button3 = new global::Guna.UI2.WinForms.Guna2Button();
			this.key = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.subscriptionDaysLabel = new global::Siticone.UI.WinForms.SiticoneLabel();
			this.guna2Button6 = new global::Guna.UI2.WinForms.Guna2Button();
			this.createDate = new global::System.Windows.Forms.Label();
			this.hwidlabel = new global::System.Windows.Forms.Label();
			this.dokiedy = new global::System.Windows.Forms.Label();
			this.nazwa = new global::System.Windows.Forms.Label();
			this.PANELhome = new global::Guna.UI2.WinForms.Guna2Panel();
			this.siticoneControlBox5 = new global::Siticone.UI.WinForms.SiticoneControlBox();
			this.SPOOFPANEL = new global::Guna.UI2.WinForms.Guna2Panel();
			this.cleanPANEL = new global::Guna.UI2.WinForms.Guna2Panel();
			this.guna2Button20 = new global::Guna.UI2.WinForms.Guna2Button();
			this.textBox1 = new global::System.Windows.Forms.TextBox();
			this.guna2Button19 = new global::Guna.UI2.WinForms.Guna2Button();
			this.guna2Button18 = new global::Guna.UI2.WinForms.Guna2Button();
			this.guna2Button16 = new global::Guna.UI2.WinForms.Guna2Button();
			this.siticoneControlBox7 = new global::Siticone.UI.WinForms.SiticoneControlBox();
			this.guna2Panel3 = new global::Guna.UI2.WinForms.Guna2Panel();
			this.label22 = new global::System.Windows.Forms.Label();
			this.guna2Button17 = new global::Guna.UI2.WinForms.Guna2Button();
			this.label23 = new global::System.Windows.Forms.Label();
			this.label24 = new global::System.Windows.Forms.Label();
			this.label25 = new global::System.Windows.Forms.Label();
			this.label26 = new global::System.Windows.Forms.Label();
			this.siticoneControlBox8 = new global::Siticone.UI.WinForms.SiticoneControlBox();
			this.siticoneControlBox3 = new global::Siticone.UI.WinForms.SiticoneControlBox();
			this.guna2Panel4 = new global::Guna.UI2.WinForms.Guna2Panel();
			this.label17 = new global::System.Windows.Forms.Label();
			this.guna2Button15 = new global::Guna.UI2.WinForms.Guna2Button();
			this.label18 = new global::System.Windows.Forms.Label();
			this.label19 = new global::System.Windows.Forms.Label();
			this.label20 = new global::System.Windows.Forms.Label();
			this.label21 = new global::System.Windows.Forms.Label();
			this.siticoneControlBox4 = new global::Siticone.UI.WinForms.SiticoneControlBox();
			this.label7 = new global::System.Windows.Forms.Label();
			this.label8 = new global::System.Windows.Forms.Label();
			this.guna2Button9 = new global::Guna.UI2.WinForms.Guna2Button();
			this.label9 = new global::System.Windows.Forms.Label();
			this.checkbox = new global::Guna.UI2.WinForms.Guna2Button();
			this.label10 = new global::System.Windows.Forms.Label();
			this.guna2Button2 = new global::Guna.UI2.WinForms.Guna2Button();
			this.label11 = new global::System.Windows.Forms.Label();
			this.guna2Button5 = new global::Guna.UI2.WinForms.Guna2Button();
			this.guna2Button10 = new global::Guna.UI2.WinForms.Guna2Button();
			this.guna2Button11 = new global::Guna.UI2.WinForms.Guna2Button();
			this.guna2Button8 = new global::Guna.UI2.WinForms.Guna2Button();
			this.guna2Button12 = new global::Guna.UI2.WinForms.Guna2Button();
			this.label2 = new global::System.Windows.Forms.Label();
			this.guna2Button13 = new global::Guna.UI2.WinForms.Guna2Button();
			this.label3 = new global::System.Windows.Forms.Label();
			this.guna2Button14 = new global::Guna.UI2.WinForms.Guna2Button();
			this.label4 = new global::System.Windows.Forms.Label();
			this.label5 = new global::System.Windows.Forms.Label();
			this.label6 = new global::System.Windows.Forms.Label();
			this.siticoneControlBox6 = new global::Siticone.UI.WinForms.SiticoneControlBox();
			this.guna2Panel1 = new global::Guna.UI2.WinForms.Guna2Panel();
			this.label12 = new global::System.Windows.Forms.Label();
			this.guna2Button1 = new global::Guna.UI2.WinForms.Guna2Button();
			this.label13 = new global::System.Windows.Forms.Label();
			this.label14 = new global::System.Windows.Forms.Label();
			this.label15 = new global::System.Windows.Forms.Label();
			this.label16 = new global::System.Windows.Forms.Label();
			this.version = new global::System.Windows.Forms.Label();
			this.guna2Button7 = new global::Guna.UI2.WinForms.Guna2Button();
			this.cleanBTN = new global::Guna.UI2.WinForms.Guna2Button();
			this.PANELhome.SuspendLayout();
			this.SPOOFPANEL.SuspendLayout();
			this.cleanPANEL.SuspendLayout();
			this.guna2Panel3.SuspendLayout();
			this.guna2Panel4.SuspendLayout();
			this.guna2Panel1.SuspendLayout();
			base.SuspendLayout();
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Segoe UI Light", 10f);
			this.label1.ForeColor = global::System.Drawing.Color.White;
			this.label1.Location = new global::System.Drawing.Point(-1, 136);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(0, 19);
			this.label1.TabIndex = 22;
			this.label1.Click += new global::System.EventHandler(this.label1_Click);
			this.guna2BorderlessForm1.AnimationInterval = 100;
			this.guna2BorderlessForm1.AnimationType = global::Guna.UI2.WinForms.Guna2BorderlessForm.AnimateWindowType.AW_CENTER;
			this.guna2BorderlessForm1.BorderRadius = 30;
			this.guna2BorderlessForm1.ContainerControl = this;
			this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6;
			this.guna2BorderlessForm1.ResizeForm = false;
			this.guna2BorderlessForm1.TransparentWhileDrag = true;
			this.homeBTN.Animated = true;
			this.homeBTN.AnimatedGIF = true;
			this.homeBTN.BackColor = global::System.Drawing.Color.Transparent;
			this.homeBTN.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.homeBTN.BorderColor = global::System.Drawing.Color.Transparent;
			this.homeBTN.BorderRadius = 5;
			this.homeBTN.ButtonMode = global::Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
			this.homeBTN.Checked = true;
			this.homeBTN.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.homeBTN.CustomBorderColor = global::System.Drawing.Color.Transparent;
			this.homeBTN.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.homeBTN.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.homeBTN.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.homeBTN.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.homeBTN.FillColor = global::System.Drawing.Color.Transparent;
			this.homeBTN.FocusedColor = global::System.Drawing.Color.Transparent;
			this.homeBTN.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.homeBTN.ForeColor = global::System.Drawing.Color.FromArgb(146, 93, 255);
			this.homeBTN.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("homeBTN.Image");
			this.homeBTN.Location = new global::System.Drawing.Point(27, 245);
			this.homeBTN.Name = "homeBTN";
			this.homeBTN.PressedColor = global::System.Drawing.Color.FromArgb(146, 93, 255);
			this.homeBTN.Size = new global::System.Drawing.Size(35, 35);
			this.homeBTN.TabIndex = 46;
			this.homeBTN.UseTransparentBackground = true;
			this.homeBTN.Click += new global::System.EventHandler(this.homeBTN_Click);
			this.settingsBTN.Animated = true;
			this.settingsBTN.AnimatedGIF = true;
			this.settingsBTN.BackColor = global::System.Drawing.Color.Transparent;
			this.settingsBTN.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.settingsBTN.BorderColor = global::System.Drawing.Color.Transparent;
			this.settingsBTN.BorderRadius = 5;
			this.settingsBTN.ButtonMode = global::Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
			this.settingsBTN.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.settingsBTN.CustomBorderColor = global::System.Drawing.Color.Transparent;
			this.settingsBTN.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.settingsBTN.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.settingsBTN.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.settingsBTN.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.settingsBTN.FillColor = global::System.Drawing.Color.Transparent;
			this.settingsBTN.FocusedColor = global::System.Drawing.Color.Red;
			this.settingsBTN.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.settingsBTN.ForeColor = global::System.Drawing.Color.FromArgb(146, 93, 255);
			this.settingsBTN.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("settingsBTN.Image");
			this.settingsBTN.Location = new global::System.Drawing.Point(27, 286);
			this.settingsBTN.Name = "settingsBTN";
			this.settingsBTN.PressedColor = global::System.Drawing.Color.FromArgb(146, 93, 255);
			this.settingsBTN.Size = new global::System.Drawing.Size(35, 35);
			this.settingsBTN.TabIndex = 47;
			this.settingsBTN.UseTransparentBackground = true;
			this.settingsBTN.Click += new global::System.EventHandler(this.settingsBTN_Click);
			this.siticoneControlBox1.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.siticoneControlBox1.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox1.BorderRadius = 10;
			this.siticoneControlBox1.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox1.HoveredState.FillColor = global::System.Drawing.Color.FromArgb(232, 17, 35);
			this.siticoneControlBox1.HoveredState.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox1.HoveredState.Parent = this.siticoneControlBox1;
			this.siticoneControlBox1.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox1.Location = new global::System.Drawing.Point(918, 10);
			this.siticoneControlBox1.Name = "siticoneControlBox1";
			this.siticoneControlBox1.ShadowDecoration.Parent = this.siticoneControlBox1;
			this.siticoneControlBox1.Size = new global::System.Drawing.Size(30, 26);
			this.siticoneControlBox1.TabIndex = 1;
			this.siticoneControlBox1.Click += new global::System.EventHandler(this.siticoneControlBox1_Click);
			this.siticoneControlBox2.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.siticoneControlBox2.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox2.BorderRadius = 10;
			this.siticoneControlBox2.ControlBoxType = global::Siticone.UI.WinForms.Enums.ControlBoxType.MinimizeBox;
			this.siticoneControlBox2.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox2.HoveredState.Parent = this.siticoneControlBox2;
			this.siticoneControlBox2.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox2.Location = new global::System.Drawing.Point(882, 10);
			this.siticoneControlBox2.Name = "siticoneControlBox2";
			this.siticoneControlBox2.ShadowDecoration.Parent = this.siticoneControlBox2;
			this.siticoneControlBox2.Size = new global::System.Drawing.Size(30, 26);
			this.siticoneControlBox2.TabIndex = 2;
			this.siticoneControlBox2.Click += new global::System.EventHandler(this.siticoneControlBox2_Click);
			this.guna2Button4.Animated = true;
			this.guna2Button4.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button4.BorderColor = global::System.Drawing.Color.SeaShell;
			this.guna2Button4.BorderRadius = 7;
			this.guna2Button4.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button4.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button4.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button4.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button4.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button4.FillColor = global::System.Drawing.Color.Transparent;
			this.guna2Button4.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button4.ForeColor = global::System.Drawing.Color.Transparent;
			this.guna2Button4.Location = new global::System.Drawing.Point(601, 293);
			this.guna2Button4.Name = "guna2Button4";
			this.guna2Button4.PressedColor = global::System.Drawing.Color.Transparent;
			this.guna2Button4.PressedDepth = 20;
			this.guna2Button4.Size = new global::System.Drawing.Size(126, 271);
			this.guna2Button4.TabIndex = 42;
			this.guna2Button4.Click += new global::System.EventHandler(this.guna2Button4_Click);
			this.guna2Button3.Animated = true;
			this.guna2Button3.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button3.BorderColor = global::System.Drawing.Color.SeaShell;
			this.guna2Button3.BorderRadius = 7;
			this.guna2Button3.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button3.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button3.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button3.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button3.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button3.FillColor = global::System.Drawing.Color.Transparent;
			this.guna2Button3.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button3.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button3.Location = new global::System.Drawing.Point(602, 25);
			this.guna2Button3.Name = "guna2Button3";
			this.guna2Button3.PressedColor = global::System.Drawing.Color.Gainsboro;
			this.guna2Button3.PressedDepth = 20;
			this.guna2Button3.Size = new global::System.Drawing.Size(125, 264);
			this.guna2Button3.TabIndex = 41;
			this.guna2Button3.Click += new global::System.EventHandler(this.guna2Button3_Click_1);
			this.key.BackColor = global::System.Drawing.Color.Transparent;
			this.key.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold);
			this.key.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.key.Location = new global::System.Drawing.Point(329, 364);
			this.key.Margin = new global::System.Windows.Forms.Padding(2);
			this.key.Name = "key";
			this.key.Size = new global::System.Drawing.Size(92, 17);
			this.key.TabIndex = 37;
			this.key.Text = "usernameLabel";
			this.key.TextAlignment = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.key.Click += new global::System.EventHandler(this.key_Click);
			this.subscriptionDaysLabel.BackColor = global::System.Drawing.Color.Transparent;
			this.subscriptionDaysLabel.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.subscriptionDaysLabel.ForeColor = global::System.Drawing.SystemColors.ButtonHighlight;
			this.subscriptionDaysLabel.Location = new global::System.Drawing.Point(223, 337);
			this.subscriptionDaysLabel.Margin = new global::System.Windows.Forms.Padding(2);
			this.subscriptionDaysLabel.Name = "subscriptionDaysLabel";
			this.subscriptionDaysLabel.Size = new global::System.Drawing.Size(69, 17);
			this.subscriptionDaysLabel.TabIndex = 38;
			this.subscriptionDaysLabel.Text = "expiryLabel";
			this.subscriptionDaysLabel.Click += new global::System.EventHandler(this.expiry_Click);
			this.guna2Button6.BorderRadius = 3;
			this.guna2Button6.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button6.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button6.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button6.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button6.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button6.FillColor = global::System.Drawing.Color.FromArgb(116, 73, 255);
			this.guna2Button6.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold);
			this.guna2Button6.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button6.Location = new global::System.Drawing.Point(595, 432);
			this.guna2Button6.Name = "guna2Button6";
			this.guna2Button6.Size = new global::System.Drawing.Size(72, 23);
			this.guna2Button6.TabIndex = 53;
			this.guna2Button6.Text = "SHOW";
			this.guna2Button6.Click += new global::System.EventHandler(this.guna2Button6_Click);
			this.createDate.AutoSize = true;
			this.createDate.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.createDate.ForeColor = global::System.Drawing.Color.White;
			this.createDate.Location = new global::System.Drawing.Point(479, 149);
			this.createDate.Name = "createDate";
			this.createDate.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.createDate.Size = new global::System.Drawing.Size(173, 17);
			this.createDate.TabIndex = 52;
			this.createDate.Text = "MOON_CREATIONDATE";
			this.createDate.TextAlign = global::System.Drawing.ContentAlignment.BottomRight;
			this.createDate.Click += new global::System.EventHandler(this.createDate_Click);
			this.hwidlabel.AutoSize = true;
			this.hwidlabel.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.hwidlabel.ForeColor = global::System.Drawing.Color.White;
			this.hwidlabel.Location = new global::System.Drawing.Point(127, 435);
			this.hwidlabel.Name = "hwidlabel";
			this.hwidlabel.Size = new global::System.Drawing.Size(72, 19);
			this.hwidlabel.TabIndex = 51;
			this.hwidlabel.Text = "HIDDEN";
			this.hwidlabel.Click += new global::System.EventHandler(this.hwidlabel_Click);
			this.dokiedy.AutoSize = true;
			this.dokiedy.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.dokiedy.ForeColor = global::System.Drawing.Color.White;
			this.dokiedy.Location = new global::System.Drawing.Point(126, 292);
			this.dokiedy.Name = "dokiedy";
			this.dokiedy.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.dokiedy.Size = new global::System.Drawing.Size(113, 17);
			this.dokiedy.TabIndex = 52;
			this.dokiedy.Text = "MOON_EXPIRY";
			this.dokiedy.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.dokiedy.Click += new global::System.EventHandler(this.dokiedy_Click);
			this.nazwa.AutoSize = true;
			this.nazwa.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.nazwa.ForeColor = global::System.Drawing.Color.White;
			this.nazwa.Location = new global::System.Drawing.Point(126, 148);
			this.nazwa.Name = "nazwa";
			this.nazwa.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.nazwa.Size = new global::System.Drawing.Size(155, 18);
			this.nazwa.TabIndex = 51;
			this.nazwa.Text = "MOON_USERNAME";
			this.nazwa.TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.nazwa.Click += new global::System.EventHandler(this.nazwa_Click);
			this.PANELhome.BackColor = global::System.Drawing.Color.Transparent;
			this.PANELhome.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("PANELhome.BackgroundImage");
			this.PANELhome.Controls.Add(this.siticoneControlBox5);
			this.PANELhome.Controls.Add(this.SPOOFPANEL);
			this.PANELhome.Controls.Add(this.siticoneControlBox6);
			this.PANELhome.Controls.Add(this.guna2Panel1);
			this.PANELhome.Controls.Add(this.version);
			this.PANELhome.Controls.Add(this.guna2Button6);
			this.PANELhome.Controls.Add(this.createDate);
			this.PANELhome.Controls.Add(this.dokiedy);
			this.PANELhome.Controls.Add(this.nazwa);
			this.PANELhome.Controls.Add(this.hwidlabel);
			this.PANELhome.Location = new global::System.Drawing.Point(88, 2);
			this.PANELhome.Name = "PANELhome";
			this.PANELhome.Size = new global::System.Drawing.Size(871, 582);
			this.PANELhome.TabIndex = 54;
			this.PANELhome.Paint += new global::System.Windows.Forms.PaintEventHandler(this.guna2Panel3_Paint);
			this.siticoneControlBox5.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.siticoneControlBox5.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox5.BorderColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox5.BorderRadius = 10;
			this.siticoneControlBox5.ControlBoxType = global::Siticone.UI.WinForms.Enums.ControlBoxType.MinimizeBox;
			this.siticoneControlBox5.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox5.HoveredState.FillColor = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.siticoneControlBox5.HoveredState.IconColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
			this.siticoneControlBox5.HoveredState.Parent = this.siticoneControlBox5;
			this.siticoneControlBox5.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox5.Location = new global::System.Drawing.Point(764, 7);
			this.siticoneControlBox5.Name = "siticoneControlBox5";
			this.siticoneControlBox5.ShadowDecoration.Parent = this.siticoneControlBox5;
			this.siticoneControlBox5.Size = new global::System.Drawing.Size(45, 29);
			this.siticoneControlBox5.TabIndex = 65;
			this.SPOOFPANEL.BackColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.SPOOFPANEL.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("SPOOFPANEL.BackgroundImage");
			this.SPOOFPANEL.Controls.Add(this.cleanPANEL);
			this.SPOOFPANEL.Controls.Add(this.siticoneControlBox3);
			this.SPOOFPANEL.Controls.Add(this.guna2Panel4);
			this.SPOOFPANEL.Controls.Add(this.siticoneControlBox4);
			this.SPOOFPANEL.Controls.Add(this.guna2Button4);
			this.SPOOFPANEL.Controls.Add(this.guna2Button3);
			this.SPOOFPANEL.Controls.Add(this.label7);
			this.SPOOFPANEL.Controls.Add(this.label8);
			this.SPOOFPANEL.Controls.Add(this.guna2Button9);
			this.SPOOFPANEL.Controls.Add(this.label9);
			this.SPOOFPANEL.Controls.Add(this.checkbox);
			this.SPOOFPANEL.Controls.Add(this.label10);
			this.SPOOFPANEL.Controls.Add(this.guna2Button2);
			this.SPOOFPANEL.Controls.Add(this.label11);
			this.SPOOFPANEL.Controls.Add(this.guna2Button5);
			this.SPOOFPANEL.Controls.Add(this.guna2Button10);
			this.SPOOFPANEL.Controls.Add(this.guna2Button11);
			this.SPOOFPANEL.Controls.Add(this.guna2Button8);
			this.SPOOFPANEL.Controls.Add(this.guna2Button12);
			this.SPOOFPANEL.Controls.Add(this.label2);
			this.SPOOFPANEL.Controls.Add(this.guna2Button13);
			this.SPOOFPANEL.Controls.Add(this.label3);
			this.SPOOFPANEL.Controls.Add(this.guna2Button14);
			this.SPOOFPANEL.Controls.Add(this.label4);
			this.SPOOFPANEL.Controls.Add(this.label5);
			this.SPOOFPANEL.Controls.Add(this.label6);
			this.SPOOFPANEL.Location = new global::System.Drawing.Point(0, 0);
			this.SPOOFPANEL.Name = "SPOOFPANEL";
			this.SPOOFPANEL.Size = new global::System.Drawing.Size(871, 582);
			this.SPOOFPANEL.TabIndex = 59;
			this.SPOOFPANEL.Visible = false;
			this.SPOOFPANEL.Paint += new global::System.Windows.Forms.PaintEventHandler(this.SPOOFPANEL_Paint);
			this.cleanPANEL.BackColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.cleanPANEL.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("cleanPANEL.BackgroundImage");
			this.cleanPANEL.Controls.Add(this.guna2Button20);
			this.cleanPANEL.Controls.Add(this.textBox1);
			this.cleanPANEL.Controls.Add(this.guna2Button19);
			this.cleanPANEL.Controls.Add(this.guna2Button18);
			this.cleanPANEL.Controls.Add(this.guna2Button16);
			this.cleanPANEL.Controls.Add(this.siticoneControlBox7);
			this.cleanPANEL.Controls.Add(this.guna2Panel3);
			this.cleanPANEL.Controls.Add(this.siticoneControlBox8);
			this.cleanPANEL.Location = new global::System.Drawing.Point(0, 0);
			this.cleanPANEL.Name = "cleanPANEL";
			this.cleanPANEL.Size = new global::System.Drawing.Size(871, 582);
			this.cleanPANEL.TabIndex = 64;
			this.cleanPANEL.Visible = false;
			this.guna2Button20.Animated = true;
			this.guna2Button20.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button20.BorderColor = global::System.Drawing.Color.Transparent;
			this.guna2Button20.BorderRadius = 10;
			this.guna2Button20.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button20.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button20.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button20.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button20.FillColor = global::System.Drawing.Color.Transparent;
			this.guna2Button20.Font = new global::System.Drawing.Font("Arial", 9.75f);
			this.guna2Button20.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button20.Location = new global::System.Drawing.Point(106, 470);
			this.guna2Button20.Name = "guna2Button20";
			this.guna2Button20.Size = new global::System.Drawing.Size(666, 60);
			this.guna2Button20.TabIndex = 63;
			this.guna2Button20.Click += new global::System.EventHandler(this.guna2Button20_Click_1);
			this.textBox1.BackColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.textBox1.BorderStyle = global::System.Windows.Forms.BorderStyle.None;
			this.textBox1.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.textBox1.ForeColor = global::System.Drawing.Color.FromArgb(116, 73, 255);
			this.textBox1.Location = new global::System.Drawing.Point(139, 405);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new global::System.Drawing.Size(588, 18);
			this.textBox1.TabIndex = 62;
			this.guna2Button19.Animated = true;
			this.guna2Button19.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button19.BorderColor = global::System.Drawing.Color.Transparent;
			this.guna2Button19.BorderRadius = 10;
			this.guna2Button19.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button19.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button19.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button19.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button19.FillColor = global::System.Drawing.Color.Transparent;
			this.guna2Button19.Font = new global::System.Drawing.Font("Arial", 9.75f);
			this.guna2Button19.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button19.Location = new global::System.Drawing.Point(195, 256);
			this.guna2Button19.Name = "guna2Button19";
			this.guna2Button19.Size = new global::System.Drawing.Size(480, 49);
			this.guna2Button19.TabIndex = 61;
			this.guna2Button19.Click += new global::System.EventHandler(this.guna2Button19_Click_1);
			this.guna2Button18.Animated = true;
			this.guna2Button18.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button18.BorderColor = global::System.Drawing.Color.Transparent;
			this.guna2Button18.BorderRadius = 10;
			this.guna2Button18.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button18.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button18.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button18.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button18.FillColor = global::System.Drawing.Color.Transparent;
			this.guna2Button18.Font = new global::System.Drawing.Font("Arial", 9.75f);
			this.guna2Button18.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button18.Location = new global::System.Drawing.Point(498, 108);
			this.guna2Button18.Name = "guna2Button18";
			this.guna2Button18.Size = new global::System.Drawing.Size(225, 52);
			this.guna2Button18.TabIndex = 60;
			this.guna2Button18.Click += new global::System.EventHandler(this.guna2Button18_Click_1);
			this.guna2Button16.Animated = true;
			this.guna2Button16.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button16.BorderColor = global::System.Drawing.Color.Transparent;
			this.guna2Button16.BorderRadius = 10;
			this.guna2Button16.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button16.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button16.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button16.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button16.FillColor = global::System.Drawing.Color.Transparent;
			this.guna2Button16.Font = new global::System.Drawing.Font("Arial", 9.75f);
			this.guna2Button16.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button16.Location = new global::System.Drawing.Point(147, 108);
			this.guna2Button16.Name = "guna2Button16";
			this.guna2Button16.Size = new global::System.Drawing.Size(225, 52);
			this.guna2Button16.TabIndex = 59;
			this.guna2Button16.Click += new global::System.EventHandler(this.guna2Button16_Click_2);
			this.siticoneControlBox7.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.siticoneControlBox7.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox7.BorderColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox7.BorderRadius = 10;
			this.siticoneControlBox7.ControlBoxType = global::Siticone.UI.WinForms.Enums.ControlBoxType.MinimizeBox;
			this.siticoneControlBox7.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox7.HoveredState.FillColor = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.siticoneControlBox7.HoveredState.IconColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
			this.siticoneControlBox7.HoveredState.Parent = this.siticoneControlBox7;
			this.siticoneControlBox7.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox7.Location = new global::System.Drawing.Point(764, 7);
			this.siticoneControlBox7.Name = "siticoneControlBox7";
			this.siticoneControlBox7.ShadowDecoration.Parent = this.siticoneControlBox7;
			this.siticoneControlBox7.Size = new global::System.Drawing.Size(45, 29);
			this.siticoneControlBox7.TabIndex = 57;
			this.guna2Panel3.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Panel3.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("guna2Panel3.BackgroundImage");
			this.guna2Panel3.Controls.Add(this.label22);
			this.guna2Panel3.Controls.Add(this.guna2Button17);
			this.guna2Panel3.Controls.Add(this.label23);
			this.guna2Panel3.Controls.Add(this.label24);
			this.guna2Panel3.Controls.Add(this.label25);
			this.guna2Panel3.Controls.Add(this.label26);
			this.guna2Panel3.Location = new global::System.Drawing.Point(8, 8);
			this.guna2Panel3.Name = "guna2Panel3";
			this.guna2Panel3.Size = new global::System.Drawing.Size(0, 0);
			this.guna2Panel3.TabIndex = 58;
			this.label22.AutoSize = true;
			this.label22.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label22.ForeColor = global::System.Drawing.Color.White;
			this.label22.Location = new global::System.Drawing.Point(479, 292);
			this.label22.Name = "label22";
			this.label22.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label22.Size = new global::System.Drawing.Size(126, 17);
			this.label22.TabIndex = 57;
			this.label22.Text = "MOON_VERSION";
			this.label22.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.guna2Button17.BorderRadius = 3;
			this.guna2Button17.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button17.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button17.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button17.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button17.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button17.FillColor = global::System.Drawing.Color.FromArgb(116, 73, 255);
			this.guna2Button17.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold);
			this.guna2Button17.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button17.Location = new global::System.Drawing.Point(595, 432);
			this.guna2Button17.Name = "guna2Button17";
			this.guna2Button17.Size = new global::System.Drawing.Size(72, 23);
			this.guna2Button17.TabIndex = 53;
			this.guna2Button17.Text = "SHOW";
			this.label23.AutoSize = true;
			this.label23.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label23.ForeColor = global::System.Drawing.Color.White;
			this.label23.Location = new global::System.Drawing.Point(479, 149);
			this.label23.Name = "label23";
			this.label23.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label23.Size = new global::System.Drawing.Size(173, 17);
			this.label23.TabIndex = 52;
			this.label23.Text = "MOON_CREATIONDATE";
			this.label23.TextAlign = global::System.Drawing.ContentAlignment.BottomRight;
			this.label24.AutoSize = true;
			this.label24.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label24.ForeColor = global::System.Drawing.Color.White;
			this.label24.Location = new global::System.Drawing.Point(126, 292);
			this.label24.Name = "label24";
			this.label24.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label24.Size = new global::System.Drawing.Size(113, 17);
			this.label24.TabIndex = 52;
			this.label24.Text = "MOON_EXPIRY";
			this.label24.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.label25.AutoSize = true;
			this.label25.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label25.ForeColor = global::System.Drawing.Color.White;
			this.label25.Location = new global::System.Drawing.Point(126, 148);
			this.label25.Name = "label25";
			this.label25.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label25.Size = new global::System.Drawing.Size(155, 18);
			this.label25.TabIndex = 51;
			this.label25.Text = "MOON_USERNAME";
			this.label25.TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.label26.AutoSize = true;
			this.label26.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label26.ForeColor = global::System.Drawing.Color.White;
			this.label26.Location = new global::System.Drawing.Point(127, 435);
			this.label26.Name = "label26";
			this.label26.Size = new global::System.Drawing.Size(72, 19);
			this.label26.TabIndex = 51;
			this.label26.Text = "HIDDEN";
			this.siticoneControlBox8.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.siticoneControlBox8.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox8.BorderRadius = 5;
			this.siticoneControlBox8.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox8.HoveredState.FillColor = global::System.Drawing.Color.FromArgb(232, 17, 35);
			this.siticoneControlBox8.HoveredState.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox8.HoveredState.Parent = this.siticoneControlBox8;
			this.siticoneControlBox8.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox8.Location = new global::System.Drawing.Point(815, 7);
			this.siticoneControlBox8.Name = "siticoneControlBox8";
			this.siticoneControlBox8.ShadowDecoration.Parent = this.siticoneControlBox8;
			this.siticoneControlBox8.Size = new global::System.Drawing.Size(45, 29);
			this.siticoneControlBox8.TabIndex = 56;
			this.siticoneControlBox3.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.siticoneControlBox3.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox3.BorderColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox3.BorderRadius = 10;
			this.siticoneControlBox3.ControlBoxType = global::Siticone.UI.WinForms.Enums.ControlBoxType.MinimizeBox;
			this.siticoneControlBox3.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox3.HoveredState.FillColor = global::System.Drawing.Color.FromArgb(255, 255, 255);
			this.siticoneControlBox3.HoveredState.IconColor = global::System.Drawing.Color.FromArgb(0, 0, 0);
			this.siticoneControlBox3.HoveredState.Parent = this.siticoneControlBox3;
			this.siticoneControlBox3.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox3.Location = new global::System.Drawing.Point(764, 7);
			this.siticoneControlBox3.Name = "siticoneControlBox3";
			this.siticoneControlBox3.ShadowDecoration.Parent = this.siticoneControlBox3;
			this.siticoneControlBox3.Size = new global::System.Drawing.Size(45, 29);
			this.siticoneControlBox3.TabIndex = 57;
			this.siticoneControlBox3.Click += new global::System.EventHandler(this.siticoneControlBox3_Click);
			this.guna2Panel4.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Panel4.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("guna2Panel4.BackgroundImage");
			this.guna2Panel4.Controls.Add(this.label17);
			this.guna2Panel4.Controls.Add(this.guna2Button15);
			this.guna2Panel4.Controls.Add(this.label18);
			this.guna2Panel4.Controls.Add(this.label19);
			this.guna2Panel4.Controls.Add(this.label20);
			this.guna2Panel4.Controls.Add(this.label21);
			this.guna2Panel4.Location = new global::System.Drawing.Point(8, 8);
			this.guna2Panel4.Name = "guna2Panel4";
			this.guna2Panel4.Size = new global::System.Drawing.Size(0, 0);
			this.guna2Panel4.TabIndex = 58;
			this.label17.AutoSize = true;
			this.label17.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label17.ForeColor = global::System.Drawing.Color.White;
			this.label17.Location = new global::System.Drawing.Point(479, 292);
			this.label17.Name = "label17";
			this.label17.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label17.Size = new global::System.Drawing.Size(126, 17);
			this.label17.TabIndex = 57;
			this.label17.Text = "MOON_VERSION";
			this.label17.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.guna2Button15.BorderRadius = 3;
			this.guna2Button15.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button15.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button15.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button15.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button15.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button15.FillColor = global::System.Drawing.Color.FromArgb(116, 73, 255);
			this.guna2Button15.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold);
			this.guna2Button15.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button15.Location = new global::System.Drawing.Point(595, 432);
			this.guna2Button15.Name = "guna2Button15";
			this.guna2Button15.Size = new global::System.Drawing.Size(72, 23);
			this.guna2Button15.TabIndex = 53;
			this.guna2Button15.Text = "SHOW";
			this.label18.AutoSize = true;
			this.label18.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label18.ForeColor = global::System.Drawing.Color.White;
			this.label18.Location = new global::System.Drawing.Point(479, 149);
			this.label18.Name = "label18";
			this.label18.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label18.Size = new global::System.Drawing.Size(173, 17);
			this.label18.TabIndex = 52;
			this.label18.Text = "MOON_CREATIONDATE";
			this.label18.TextAlign = global::System.Drawing.ContentAlignment.BottomRight;
			this.label19.AutoSize = true;
			this.label19.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label19.ForeColor = global::System.Drawing.Color.White;
			this.label19.Location = new global::System.Drawing.Point(126, 292);
			this.label19.Name = "label19";
			this.label19.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label19.Size = new global::System.Drawing.Size(113, 17);
			this.label19.TabIndex = 52;
			this.label19.Text = "MOON_EXPIRY";
			this.label19.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.label20.AutoSize = true;
			this.label20.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label20.ForeColor = global::System.Drawing.Color.White;
			this.label20.Location = new global::System.Drawing.Point(126, 148);
			this.label20.Name = "label20";
			this.label20.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label20.Size = new global::System.Drawing.Size(155, 18);
			this.label20.TabIndex = 51;
			this.label20.Text = "MOON_USERNAME";
			this.label20.TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.label21.AutoSize = true;
			this.label21.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label21.ForeColor = global::System.Drawing.Color.White;
			this.label21.Location = new global::System.Drawing.Point(127, 435);
			this.label21.Name = "label21";
			this.label21.Size = new global::System.Drawing.Size(72, 19);
			this.label21.TabIndex = 51;
			this.label21.Text = "HIDDEN";
			this.siticoneControlBox4.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.siticoneControlBox4.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox4.BorderRadius = 5;
			this.siticoneControlBox4.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox4.HoveredState.FillColor = global::System.Drawing.Color.FromArgb(232, 17, 35);
			this.siticoneControlBox4.HoveredState.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox4.HoveredState.Parent = this.siticoneControlBox4;
			this.siticoneControlBox4.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox4.Location = new global::System.Drawing.Point(815, 7);
			this.siticoneControlBox4.Name = "siticoneControlBox4";
			this.siticoneControlBox4.ShadowDecoration.Parent = this.siticoneControlBox4;
			this.siticoneControlBox4.Size = new global::System.Drawing.Size(45, 29);
			this.siticoneControlBox4.TabIndex = 56;
			this.siticoneControlBox4.Click += new global::System.EventHandler(this.siticoneControlBox4_Click);
			this.label7.AutoSize = true;
			this.label7.BackColor = global::System.Drawing.Color.Transparent;
			this.label7.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label7.ForeColor = global::System.Drawing.SystemColors.Control;
			this.label7.Location = new global::System.Drawing.Point(211, 503);
			this.label7.Name = "label7";
			this.label7.Size = new global::System.Drawing.Size(23, 17);
			this.label7.TabIndex = 63;
			this.label7.Text = "All";
			this.label8.AutoSize = true;
			this.label8.BackColor = global::System.Drawing.Color.Transparent;
			this.label8.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label8.ForeColor = global::System.Drawing.SystemColors.Control;
			this.label8.Location = new global::System.Drawing.Point(211, 470);
			this.label8.Name = "label8";
			this.label8.Size = new global::System.Drawing.Size(67, 17);
			this.label8.TabIndex = 62;
			this.label8.Text = "Rockstar";
			this.guna2Button9.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button9.BorderRadius = 6;
			this.guna2Button9.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button9.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button9.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button9.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button9.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button9.FillColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.guna2Button9.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button9.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button9.Location = new global::System.Drawing.Point(175, 93);
			this.guna2Button9.Name = "guna2Button9";
			this.guna2Button9.Size = new global::System.Drawing.Size(30, 30);
			this.guna2Button9.TabIndex = 48;
			this.guna2Button9.Click += new global::System.EventHandler(this.guna2Button9_Click);
			this.label9.AutoSize = true;
			this.label9.BackColor = global::System.Drawing.Color.Transparent;
			this.label9.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label9.ForeColor = global::System.Drawing.SystemColors.Control;
			this.label9.Location = new global::System.Drawing.Point(211, 439);
			this.label9.Name = "label9";
			this.label9.Size = new global::System.Drawing.Size(40, 17);
			this.label9.TabIndex = 61;
			this.label9.Text = "Xbox";
			this.checkbox.BackColor = global::System.Drawing.Color.Transparent;
			this.checkbox.BorderRadius = 6;
			this.checkbox.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.checkbox.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.checkbox.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.checkbox.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.checkbox.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.checkbox.FillColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.checkbox.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.checkbox.ForeColor = global::System.Drawing.Color.White;
			this.checkbox.Location = new global::System.Drawing.Point(175, 159);
			this.checkbox.Name = "checkbox";
			this.checkbox.Size = new global::System.Drawing.Size(30, 30);
			this.checkbox.TabIndex = 44;
			this.checkbox.Click += new global::System.EventHandler(this.checkbox_Click_1);
			this.label10.AutoSize = true;
			this.label10.BackColor = global::System.Drawing.Color.Transparent;
			this.label10.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label10.ForeColor = global::System.Drawing.SystemColors.Control;
			this.label10.Location = new global::System.Drawing.Point(211, 405);
			this.label10.Name = "label10";
			this.label10.Size = new global::System.Drawing.Size(51, 17);
			this.label10.TabIndex = 60;
			this.label10.Text = "Steam";
			this.guna2Button2.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button2.BorderRadius = 6;
			this.guna2Button2.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button2.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button2.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button2.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button2.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button2.FillColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.guna2Button2.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button2.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button2.Location = new global::System.Drawing.Point(175, 192);
			this.guna2Button2.Name = "guna2Button2";
			this.guna2Button2.Size = new global::System.Drawing.Size(30, 30);
			this.guna2Button2.TabIndex = 45;
			this.guna2Button2.Click += new global::System.EventHandler(this.guna2Button2_Click_4);
			this.label11.AutoSize = true;
			this.label11.BackColor = global::System.Drawing.Color.Transparent;
			this.label11.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label11.ForeColor = global::System.Drawing.SystemColors.Control;
			this.label11.Location = new global::System.Drawing.Point(211, 373);
			this.label11.Name = "label11";
			this.label11.Size = new global::System.Drawing.Size(59, 17);
			this.label11.TabIndex = 59;
			this.label11.Text = "Discord";
			this.guna2Button5.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button5.BorderRadius = 6;
			this.guna2Button5.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button5.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button5.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button5.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button5.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button5.FillColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.guna2Button5.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button5.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button5.Location = new global::System.Drawing.Point(175, 225);
			this.guna2Button5.Name = "guna2Button5";
			this.guna2Button5.Size = new global::System.Drawing.Size(30, 30);
			this.guna2Button5.TabIndex = 46;
			this.guna2Button5.Click += new global::System.EventHandler(this.guna2Button5_Click_1);
			this.guna2Button10.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button10.BorderRadius = 6;
			this.guna2Button10.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button10.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button10.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button10.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button10.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button10.FillColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.guna2Button10.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button10.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button10.Location = new global::System.Drawing.Point(175, 366);
			this.guna2Button10.Name = "guna2Button10";
			this.guna2Button10.Size = new global::System.Drawing.Size(30, 30);
			this.guna2Button10.TabIndex = 58;
			this.guna2Button10.Click += new global::System.EventHandler(this.guna2Button10_Click);
			this.guna2Button11.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button11.BorderRadius = 6;
			this.guna2Button11.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button11.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button11.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button11.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button11.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button11.FillColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.guna2Button11.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button11.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button11.Location = new global::System.Drawing.Point(175, 399);
			this.guna2Button11.Name = "guna2Button11";
			this.guna2Button11.Size = new global::System.Drawing.Size(30, 30);
			this.guna2Button11.TabIndex = 57;
			this.guna2Button11.Click += new global::System.EventHandler(this.guna2Button11_Click);
			this.guna2Button8.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button8.BorderRadius = 6;
			this.guna2Button8.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button8.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button8.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button8.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button8.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button8.FillColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.guna2Button8.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button8.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button8.Location = new global::System.Drawing.Point(175, 126);
			this.guna2Button8.Name = "guna2Button8";
			this.guna2Button8.Size = new global::System.Drawing.Size(30, 30);
			this.guna2Button8.TabIndex = 47;
			this.guna2Button8.Click += new global::System.EventHandler(this.guna2Button8_Click);
			this.guna2Button12.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button12.BorderRadius = 6;
			this.guna2Button12.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button12.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button12.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button12.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button12.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button12.FillColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.guna2Button12.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button12.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button12.Location = new global::System.Drawing.Point(175, 498);
			this.guna2Button12.Name = "guna2Button12";
			this.guna2Button12.Size = new global::System.Drawing.Size(30, 30);
			this.guna2Button12.TabIndex = 56;
			this.guna2Button12.Click += new global::System.EventHandler(this.guna2Button12_Click);
			this.label2.AutoSize = true;
			this.label2.BackColor = global::System.Drawing.Color.Transparent;
			this.label2.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label2.ForeColor = global::System.Drawing.SystemColors.Control;
			this.label2.Location = new global::System.Drawing.Point(211, 100);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(62, 17);
			this.label2.TabIndex = 49;
			this.label2.Text = "Registry";
			this.guna2Button13.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button13.BorderRadius = 6;
			this.guna2Button13.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button13.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button13.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button13.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button13.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button13.FillColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.guna2Button13.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button13.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button13.Location = new global::System.Drawing.Point(175, 465);
			this.guna2Button13.Name = "guna2Button13";
			this.guna2Button13.Size = new global::System.Drawing.Size(30, 30);
			this.guna2Button13.TabIndex = 55;
			this.guna2Button13.Click += new global::System.EventHandler(this.guna2Button13_Click);
			this.label3.AutoSize = true;
			this.label3.BackColor = global::System.Drawing.Color.Transparent;
			this.label3.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label3.ForeColor = global::System.Drawing.SystemColors.Control;
			this.label3.Location = new global::System.Drawing.Point(211, 132);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(74, 17);
			this.label3.TabIndex = 50;
			this.label3.Text = "FiveM App";
			this.guna2Button14.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button14.BorderRadius = 6;
			this.guna2Button14.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button14.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button14.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button14.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button14.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button14.FillColor = global::System.Drawing.Color.FromArgb(9, 9, 10);
			this.guna2Button14.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button14.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button14.Location = new global::System.Drawing.Point(175, 432);
			this.guna2Button14.Name = "guna2Button14";
			this.guna2Button14.Size = new global::System.Drawing.Size(30, 30);
			this.guna2Button14.TabIndex = 54;
			this.guna2Button14.Click += new global::System.EventHandler(this.guna2Button14_Click);
			this.label4.AutoSize = true;
			this.label4.BackColor = global::System.Drawing.Color.Transparent;
			this.label4.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label4.ForeColor = global::System.Drawing.SystemColors.Control;
			this.label4.Location = new global::System.Drawing.Point(211, 166);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(64, 17);
			this.label4.TabIndex = 51;
			this.label4.Text = "AppData";
			this.label5.AutoSize = true;
			this.label5.BackColor = global::System.Drawing.Color.Transparent;
			this.label5.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label5.ForeColor = global::System.Drawing.SystemColors.Control;
			this.label5.Location = new global::System.Drawing.Point(211, 197);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(71, 17);
			this.label5.TabIndex = 52;
			this.label5.Text = "Hardware";
			this.label6.AutoSize = true;
			this.label6.BackColor = global::System.Drawing.Color.Transparent;
			this.label6.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label6.ForeColor = global::System.Drawing.SystemColors.Control;
			this.label6.Location = new global::System.Drawing.Point(211, 230);
			this.label6.Name = "label6";
			this.label6.Size = new global::System.Drawing.Size(23, 17);
			this.label6.TabIndex = 53;
			this.label6.Text = "All";
			this.siticoneControlBox6.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Right);
			this.siticoneControlBox6.BackColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox6.BorderRadius = 5;
			this.siticoneControlBox6.FillColor = global::System.Drawing.Color.Transparent;
			this.siticoneControlBox6.HoveredState.FillColor = global::System.Drawing.Color.FromArgb(232, 17, 35);
			this.siticoneControlBox6.HoveredState.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox6.HoveredState.Parent = this.siticoneControlBox6;
			this.siticoneControlBox6.IconColor = global::System.Drawing.Color.White;
			this.siticoneControlBox6.Location = new global::System.Drawing.Point(815, 7);
			this.siticoneControlBox6.Name = "siticoneControlBox6";
			this.siticoneControlBox6.ShadowDecoration.Parent = this.siticoneControlBox6;
			this.siticoneControlBox6.Size = new global::System.Drawing.Size(45, 29);
			this.siticoneControlBox6.TabIndex = 64;
			this.guna2Panel1.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Panel1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("guna2Panel1.BackgroundImage");
			this.guna2Panel1.Controls.Add(this.label12);
			this.guna2Panel1.Controls.Add(this.guna2Button1);
			this.guna2Panel1.Controls.Add(this.label13);
			this.guna2Panel1.Controls.Add(this.label14);
			this.guna2Panel1.Controls.Add(this.label15);
			this.guna2Panel1.Controls.Add(this.label16);
			this.guna2Panel1.Location = new global::System.Drawing.Point(8, 8);
			this.guna2Panel1.Name = "guna2Panel1";
			this.guna2Panel1.Size = new global::System.Drawing.Size(0, 0);
			this.guna2Panel1.TabIndex = 58;
			this.label12.AutoSize = true;
			this.label12.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label12.ForeColor = global::System.Drawing.Color.White;
			this.label12.Location = new global::System.Drawing.Point(479, 292);
			this.label12.Name = "label12";
			this.label12.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label12.Size = new global::System.Drawing.Size(126, 17);
			this.label12.TabIndex = 57;
			this.label12.Text = "MOON_VERSION";
			this.label12.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.guna2Button1.BorderRadius = 3;
			this.guna2Button1.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button1.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button1.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button1.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button1.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button1.FillColor = global::System.Drawing.Color.FromArgb(116, 73, 255);
			this.guna2Button1.Font = new global::System.Drawing.Font("Arial", 9f, global::System.Drawing.FontStyle.Bold);
			this.guna2Button1.ForeColor = global::System.Drawing.Color.White;
			this.guna2Button1.Location = new global::System.Drawing.Point(595, 432);
			this.guna2Button1.Name = "guna2Button1";
			this.guna2Button1.Size = new global::System.Drawing.Size(72, 23);
			this.guna2Button1.TabIndex = 53;
			this.guna2Button1.Text = "SHOW";
			this.label13.AutoSize = true;
			this.label13.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label13.ForeColor = global::System.Drawing.Color.White;
			this.label13.Location = new global::System.Drawing.Point(479, 149);
			this.label13.Name = "label13";
			this.label13.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label13.Size = new global::System.Drawing.Size(173, 17);
			this.label13.TabIndex = 52;
			this.label13.Text = "MOON_CREATIONDATE";
			this.label13.TextAlign = global::System.Drawing.ContentAlignment.BottomRight;
			this.label14.AutoSize = true;
			this.label14.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label14.ForeColor = global::System.Drawing.Color.White;
			this.label14.Location = new global::System.Drawing.Point(126, 292);
			this.label14.Name = "label14";
			this.label14.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label14.Size = new global::System.Drawing.Size(113, 17);
			this.label14.TabIndex = 52;
			this.label14.Text = "MOON_EXPIRY";
			this.label14.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.label15.AutoSize = true;
			this.label15.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label15.ForeColor = global::System.Drawing.Color.White;
			this.label15.Location = new global::System.Drawing.Point(126, 148);
			this.label15.Name = "label15";
			this.label15.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.label15.Size = new global::System.Drawing.Size(155, 18);
			this.label15.TabIndex = 51;
			this.label15.Text = "MOON_USERNAME";
			this.label15.TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.label16.AutoSize = true;
			this.label16.Font = new global::System.Drawing.Font("Arial", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 238);
			this.label16.ForeColor = global::System.Drawing.Color.White;
			this.label16.Location = new global::System.Drawing.Point(127, 435);
			this.label16.Name = "label16";
			this.label16.Size = new global::System.Drawing.Size(72, 19);
			this.label16.TabIndex = 51;
			this.label16.Text = "HIDDEN";
			this.version.AutoSize = true;
			this.version.Font = new global::System.Drawing.Font("Arial", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 238);
			this.version.ForeColor = global::System.Drawing.Color.White;
			this.version.Location = new global::System.Drawing.Point(479, 292);
			this.version.Name = "version";
			this.version.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.version.Size = new global::System.Drawing.Size(126, 17);
			this.version.TabIndex = 57;
			this.version.Text = "MOON_VERSION";
			this.version.TextAlign = global::System.Drawing.ContentAlignment.MiddleCenter;
			this.guna2Button7.Animated = true;
			this.guna2Button7.AnimatedGIF = true;
			this.guna2Button7.BackColor = global::System.Drawing.Color.Transparent;
			this.guna2Button7.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.guna2Button7.BorderColor = global::System.Drawing.Color.Transparent;
			this.guna2Button7.BorderRadius = 5;
			this.guna2Button7.ButtonMode = global::Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
			this.guna2Button7.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.guna2Button7.CustomBorderColor = global::System.Drawing.Color.Transparent;
			this.guna2Button7.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button7.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.guna2Button7.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.guna2Button7.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.guna2Button7.FillColor = global::System.Drawing.Color.Transparent;
			this.guna2Button7.FocusedColor = global::System.Drawing.Color.Red;
			this.guna2Button7.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.guna2Button7.ForeColor = global::System.Drawing.Color.FromArgb(146, 93, 255);
			this.guna2Button7.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("guna2Button7.Image");
			this.guna2Button7.Location = new global::System.Drawing.Point(27, 524);
			this.guna2Button7.Name = "guna2Button7";
			this.guna2Button7.PressedColor = global::System.Drawing.Color.FromArgb(146, 93, 255);
			this.guna2Button7.Size = new global::System.Drawing.Size(35, 35);
			this.guna2Button7.TabIndex = 55;
			this.guna2Button7.UseTransparentBackground = true;
			this.guna2Button7.Click += new global::System.EventHandler(this.guna2Button7_Click_1);
			this.cleanBTN.Animated = true;
			this.cleanBTN.AnimatedGIF = true;
			this.cleanBTN.BackColor = global::System.Drawing.Color.Transparent;
			this.cleanBTN.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			this.cleanBTN.BorderColor = global::System.Drawing.Color.Transparent;
			this.cleanBTN.BorderRadius = 5;
			this.cleanBTN.ButtonMode = global::Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
			this.cleanBTN.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.cleanBTN.CustomBorderColor = global::System.Drawing.Color.Transparent;
			this.cleanBTN.DisabledState.BorderColor = global::System.Drawing.Color.DarkGray;
			this.cleanBTN.DisabledState.CustomBorderColor = global::System.Drawing.Color.DarkGray;
			this.cleanBTN.DisabledState.FillColor = global::System.Drawing.Color.FromArgb(169, 169, 169);
			this.cleanBTN.DisabledState.ForeColor = global::System.Drawing.Color.FromArgb(141, 141, 141);
			this.cleanBTN.FillColor = global::System.Drawing.Color.Transparent;
			this.cleanBTN.FocusedColor = global::System.Drawing.Color.Red;
			this.cleanBTN.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.cleanBTN.ForeColor = global::System.Drawing.Color.FromArgb(146, 93, 255);
			this.cleanBTN.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("cleanBTN.Image");
			this.cleanBTN.Location = new global::System.Drawing.Point(27, 327);
			this.cleanBTN.Name = "cleanBTN";
			this.cleanBTN.PressedColor = global::System.Drawing.Color.FromArgb(146, 93, 255);
			this.cleanBTN.Size = new global::System.Drawing.Size(35, 35);
			this.cleanBTN.TabIndex = 56;
			this.cleanBTN.UseTransparentBackground = true;
			this.cleanBTN.Click += new global::System.EventHandler(this.guna2Button16_Click_1);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.AutoValidate = global::System.Windows.Forms.AutoValidate.Disable;
			this.BackColor = global::System.Drawing.Color.FromArgb(9, 9, 9);
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Zoom;
			base.ClientSize = new global::System.Drawing.Size(960, 585);
			base.Controls.Add(this.cleanBTN);
			base.Controls.Add(this.guna2Button7);
			base.Controls.Add(this.PANELhome);
			base.Controls.Add(this.siticoneControlBox1);
			base.Controls.Add(this.siticoneControlBox2);
			base.Controls.Add(this.settingsBTN);
			base.Controls.Add(this.homeBTN);
			base.Controls.Add(this.label1);
			this.DoubleBuffered = true;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "Main";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = " ";
			base.TransparencyKey = global::System.Drawing.Color.Maroon;
			base.Load += new global::System.EventHandler(this.Main_Load);
			this.PANELhome.ResumeLayout(false);
			this.PANELhome.PerformLayout();
			this.SPOOFPANEL.ResumeLayout(false);
			this.SPOOFPANEL.PerformLayout();
			this.cleanPANEL.ResumeLayout(false);
			this.cleanPANEL.PerformLayout();
			this.guna2Panel3.ResumeLayout(false);
			this.guna2Panel3.PerformLayout();
			this.guna2Panel4.ResumeLayout(false);
			this.guna2Panel4.PerformLayout();
			this.guna2Panel1.ResumeLayout(false);
			this.guna2Panel1.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000011 RID: 17
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000012 RID: 18
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000013 RID: 19
		private global::Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;

		// Token: 0x04000014 RID: 20
		private global::Guna.UI2.WinForms.Guna2Button settingsBTN;

		// Token: 0x04000015 RID: 21
		private global::Guna.UI2.WinForms.Guna2Button homeBTN;

		// Token: 0x04000016 RID: 22
		private global::Siticone.UI.WinForms.SiticoneControlBox siticoneControlBox1;

		// Token: 0x04000017 RID: 23
		private global::Siticone.UI.WinForms.SiticoneControlBox siticoneControlBox2;

		// Token: 0x04000018 RID: 24
		private global::Guna.UI2.WinForms.Guna2Button guna2Button3;

		// Token: 0x04000019 RID: 25
		private global::Guna.UI2.WinForms.Guna2Button guna2Button4;

		// Token: 0x0400001A RID: 26
		private global::Siticone.UI.WinForms.SiticoneLabel key;

		// Token: 0x0400001B RID: 27
		private global::Siticone.UI.WinForms.SiticoneLabel subscriptionDaysLabel;

		// Token: 0x0400001C RID: 28
		private global::System.Windows.Forms.Label hwidlabel;

		// Token: 0x0400001D RID: 29
		private global::System.Windows.Forms.Label createDate;

		// Token: 0x0400001E RID: 30
		private global::System.Windows.Forms.Label dokiedy;

		// Token: 0x0400001F RID: 31
		private global::System.Windows.Forms.Label nazwa;

		// Token: 0x04000020 RID: 32
		private global::Guna.UI2.WinForms.Guna2Panel PANELhome;

		// Token: 0x04000021 RID: 33
		private global::Guna.UI2.WinForms.Guna2Button guna2Button7;

		// Token: 0x04000022 RID: 34
		private global::Guna.UI2.WinForms.Guna2Button checkbox;

		// Token: 0x04000023 RID: 35
		private global::Guna.UI2.WinForms.Guna2Button guna2Button6;

		// Token: 0x04000024 RID: 36
		private global::Guna.UI2.WinForms.Guna2Button guna2Button9;

		// Token: 0x04000025 RID: 37
		private global::Guna.UI2.WinForms.Guna2Button guna2Button8;

		// Token: 0x04000026 RID: 38
		private global::Guna.UI2.WinForms.Guna2Button guna2Button5;

		// Token: 0x04000027 RID: 39
		private global::Guna.UI2.WinForms.Guna2Button guna2Button2;

		// Token: 0x04000028 RID: 40
		private global::System.Windows.Forms.Label label6;

		// Token: 0x04000029 RID: 41
		private global::System.Windows.Forms.Label label5;

		// Token: 0x0400002A RID: 42
		private global::System.Windows.Forms.Label label4;

		// Token: 0x0400002B RID: 43
		private global::System.Windows.Forms.Label label3;

		// Token: 0x0400002C RID: 44
		private global::System.Windows.Forms.Label label2;

		// Token: 0x0400002D RID: 45
		private global::System.Windows.Forms.Label label7;

		// Token: 0x0400002E RID: 46
		private global::System.Windows.Forms.Label label8;

		// Token: 0x0400002F RID: 47
		private global::System.Windows.Forms.Label label9;

		// Token: 0x04000030 RID: 48
		private global::System.Windows.Forms.Label label10;

		// Token: 0x04000031 RID: 49
		private global::System.Windows.Forms.Label label11;

		// Token: 0x04000032 RID: 50
		private global::Guna.UI2.WinForms.Guna2Button guna2Button10;

		// Token: 0x04000033 RID: 51
		private global::Guna.UI2.WinForms.Guna2Button guna2Button11;

		// Token: 0x04000034 RID: 52
		private global::Guna.UI2.WinForms.Guna2Button guna2Button12;

		// Token: 0x04000035 RID: 53
		private global::Guna.UI2.WinForms.Guna2Button guna2Button13;

		// Token: 0x04000036 RID: 54
		private global::Guna.UI2.WinForms.Guna2Button guna2Button14;

		// Token: 0x04000037 RID: 55
		private global::System.Windows.Forms.Label version;

		// Token: 0x04000038 RID: 56
		private global::Guna.UI2.WinForms.Guna2Panel guna2Panel1;

		// Token: 0x04000039 RID: 57
		private global::System.Windows.Forms.Label label12;

		// Token: 0x0400003A RID: 58
		private global::Guna.UI2.WinForms.Guna2Button guna2Button1;

		// Token: 0x0400003B RID: 59
		private global::System.Windows.Forms.Label label13;

		// Token: 0x0400003C RID: 60
		private global::System.Windows.Forms.Label label14;

		// Token: 0x0400003D RID: 61
		private global::System.Windows.Forms.Label label15;

		// Token: 0x0400003E RID: 62
		private global::System.Windows.Forms.Label label16;

		// Token: 0x0400003F RID: 63
		private global::Guna.UI2.WinForms.Guna2Panel SPOOFPANEL;

		// Token: 0x04000040 RID: 64
		private global::Guna.UI2.WinForms.Guna2Panel guna2Panel4;

		// Token: 0x04000041 RID: 65
		private global::System.Windows.Forms.Label label17;

		// Token: 0x04000042 RID: 66
		private global::Guna.UI2.WinForms.Guna2Button guna2Button15;

		// Token: 0x04000043 RID: 67
		private global::System.Windows.Forms.Label label18;

		// Token: 0x04000044 RID: 68
		private global::System.Windows.Forms.Label label19;

		// Token: 0x04000045 RID: 69
		private global::System.Windows.Forms.Label label20;

		// Token: 0x04000046 RID: 70
		private global::System.Windows.Forms.Label label21;

		// Token: 0x04000047 RID: 71
		private global::Siticone.UI.WinForms.SiticoneControlBox siticoneControlBox3;

		// Token: 0x04000048 RID: 72
		private global::Siticone.UI.WinForms.SiticoneControlBox siticoneControlBox4;

		// Token: 0x04000049 RID: 73
		private global::Siticone.UI.WinForms.SiticoneControlBox siticoneControlBox5;

		// Token: 0x0400004A RID: 74
		private global::Siticone.UI.WinForms.SiticoneControlBox siticoneControlBox6;

		// Token: 0x0400004B RID: 75
		private global::Guna.UI2.WinForms.Guna2Button cleanBTN;

		// Token: 0x0400004C RID: 76
		private global::Guna.UI2.WinForms.Guna2Panel cleanPANEL;

		// Token: 0x0400004D RID: 77
		private global::Siticone.UI.WinForms.SiticoneControlBox siticoneControlBox7;

		// Token: 0x0400004E RID: 78
		private global::Guna.UI2.WinForms.Guna2Panel guna2Panel3;

		// Token: 0x0400004F RID: 79
		private global::System.Windows.Forms.Label label22;

		// Token: 0x04000050 RID: 80
		private global::Guna.UI2.WinForms.Guna2Button guna2Button17;

		// Token: 0x04000051 RID: 81
		private global::System.Windows.Forms.Label label23;

		// Token: 0x04000052 RID: 82
		private global::System.Windows.Forms.Label label24;

		// Token: 0x04000053 RID: 83
		private global::System.Windows.Forms.Label label25;

		// Token: 0x04000054 RID: 84
		private global::System.Windows.Forms.Label label26;

		// Token: 0x04000055 RID: 85
		private global::Siticone.UI.WinForms.SiticoneControlBox siticoneControlBox8;

		// Token: 0x04000056 RID: 86
		private global::Guna.UI2.WinForms.Guna2Button guna2Button18;

		// Token: 0x04000057 RID: 87
		private global::Guna.UI2.WinForms.Guna2Button guna2Button16;

		// Token: 0x04000058 RID: 88
		private global::Guna.UI2.WinForms.Guna2Button guna2Button19;

		// Token: 0x04000059 RID: 89
		private global::Guna.UI2.WinForms.Guna2Button guna2Button20;

		// Token: 0x0400005A RID: 90
		private global::System.Windows.Forms.TextBox textBox1;
	}
}
